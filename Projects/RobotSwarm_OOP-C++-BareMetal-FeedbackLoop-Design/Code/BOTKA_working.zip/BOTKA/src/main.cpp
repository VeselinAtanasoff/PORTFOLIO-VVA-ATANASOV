#include "Timer.h"
#include "Ultrasonic.h"
#include "UI.h"

Timer timer;
Ultrasonic ultrasonic;
UI ui;


extern "C" void SysTick_Handler(void){
    timer.msTicks++;
    // Every 50 ms trigger the ultrasonic sensor
    if (timer.msTicks % 50 == 0) {
        ultrasonic.triggerSensor();
    }
}

int main(){
    ui.sendString("System Initialized!\r\n");

    while (true) {
        if(ultrasonic.checkForWall()){
            ui.sendString("Wall detected!\r\n");
        }
        ui.sendFormattedString("Distance: %d cm\r\n", ultrasonic.getDistance());
        
        timer.delay(400);
    }
}