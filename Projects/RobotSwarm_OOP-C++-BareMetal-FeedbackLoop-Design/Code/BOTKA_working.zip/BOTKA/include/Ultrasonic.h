#pragma once
#include "stm32f303xe.h"

#define PSCValue 71
#define ARRValue 59999
class Ultrasonic {
public:
    Ultrasonic();
    void triggerSensor();
    bool checkForWall();
    uint32_t getDistance();

private:
    void initGPIO();
    void initPWMOutput();
    void initPWMInput();

};